#include <iostream>
using std::cin;
using std::cout;
using std::endl;
#include <cstdio>
#include "App.h"

int main(  )
{
    App app;
	return app.Execute(  );
}