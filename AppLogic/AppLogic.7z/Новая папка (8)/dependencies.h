#ifndef DEPENDENCIES_H
#define DEPENDENCIES_H

class Renderer;
class Vec3f;
class Matrix;
class Quat;

#include "SDL.h"
#include "3d_SDL_math.h"
#include "renderer.h"
#include <math.h>

#endif