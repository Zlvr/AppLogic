# 3D-in-SDL
Simulating 3D using the 2D renderer SDL

An old project of mine written in 2011
